// Import Firebase modules
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.8.1/firebase-app.js";
import {
    getAuth,
    onAuthStateChanged,
    setPersistence,
    browserLocalPersistence
} from "https://www.gstatic.com/firebasejs/10.8.1/firebase-auth.js";
import {
    getFirestore,
    collection,
    query,
    where,
    orderBy,
    getDocs
} from "https://www.gstatic.com/firebasejs/10.8.1/firebase-firestore.js";

// Firebase config
const firebaseConfig = {
    apiKey: "AIzaSyB2u22ywAixC_E7crQ3YzPbLJM2CSKNaTs",
    authDomain: "namma-madurai-ward.firebaseapp.com",
    projectId: "namma-madurai-ward",
    storageBucket: "namma-madurai-ward.firebasestorage.app",
    messagingSenderId: "977288911674",
    appId: "1:977288911674:web:ff3830a666f3d7365ece03",
    measurementId: "G-YPKGFL1RF3"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

// Set session persistence
setPersistence(auth, browserLocalPersistence)
    .then(() => {
        console.log("Session persistence enabled");

        // Handle login state
        onAuthStateChanged(auth, (user) => {
            console.log("Checking login status...");
            if (user) {
                const userEmail = user.email;
                console.log("User logged in:", userEmail);
                loadComplaints(userEmail);
            } else {
                alert("Please login to view your complaints.");
                window.location.href = "login.html";
            }
        });
    })
    .catch((error) => {
        console.error("Persistence error:", error);
    });

// Load complaints from Firestore
async function loadComplaints(email) {
    const complaintList = document.getElementById("complaintsList");
    complaintList.innerHTML = "<p>Loading complaints...</p>";

    const q = query(
        collection(db, "complaints"),
        where("email", "==", email),
        orderBy("timestamp", "desc")
    );

    try {
        const querySnapshot = await getDocs(q);
        complaintList.innerHTML = "";

        if (querySnapshot.empty) {
            complaintList.innerHTML = "<p>No complaints found for your account.</p>";
            return;
        }

        querySnapshot.forEach((doc) => {
            const data = doc.data();
            const formattedDate = formatTimestamp(data.timestamp);

            const complaintCard = `
                <div class="complaint-card">
                    <h3>Complaint ID: ${data.complaint_id}</h3>
                    <p><strong>Category:</strong> ${data.category}</p>
                    <p><strong>Description:</strong> ${data.description}</p>
                    <p><strong>Status:</strong> ${data.status}</p>
                    <p><strong>Ward:</strong> ${data.wardNumber}, <strong>Zone:</strong> ${data.zoneNumber}</p>
                    <p><strong>Locality:</strong> ${data.localityName}</p>
                    <p><strong>Date:</strong> ${formattedDate}</p>
                </div>
                <hr/>
            `;
            complaintList.innerHTML += complaintCard;
        });
    } catch (error) {
        console.error("Error getting complaints:", error);
        complaintList.innerHTML = "<p>Error loading complaints.</p>";
    }
}

// Format Firestore Timestamp
function formatTimestamp(timestamp) {
    if (!timestamp || !timestamp.toDate) return "N/A";
    const dateObj = timestamp.toDate();
    const options = {
        year: "numeric",
        month: "short",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit",
        hour12: true
    };
    return dateObj.toLocaleString("en-IN", options);
}
