import { initializeApp, getApps } from "https://www.gstatic.com/firebasejs/11.4.0/firebase-app.js";
import {
  getAuth,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  onAuthStateChanged,
  signOut
} from "https://www.gstatic.com/firebasejs/11.4.0/firebase-auth.js";
import {
  getFirestore,
  doc,
  setDoc,
  getDoc,
  collection,
  getDocs,
  updateDoc
} from "https://www.gstatic.com/firebasejs/11.4.0/firebase-firestore.js";

// Firebase Configuration
const firebaseConfig = {
  apiKey: "AIzaSyB2u22ywAixC_E7crQ3YzPbLJM2CSKNaTs",
  authDomain: "namma-madurai-ward.firebaseapp.com",
  projectId: "namma-madurai-ward",
};

// Prevent duplicate Firebase initialization
if (!getApps().length) {
  initializeApp(firebaseConfig);
}

const auth = getAuth();
const db = getFirestore();

var councilorLocality = ""
let currentUser = null;


// Register Function (storing locality during registration)
// async function registerCouncilor(email, password, locality) {
//   try {
//     const userCredential = await createUserWithEmailAndPassword(auth, email, password);
//     const user = userCredential.user;

//     // Save the locality field during registration
//     await setDoc(doc(db, "councillors", user.uid), {
//       locality: locality, // Store the locality value entered by the councilor
//     });

//     console.log("✅ Councilor registered successfully:", email);
//     alert("✅ Councilor registered successfully!");
//     window.location.href = "Councillor_login.html"; // Redirect to login page after registration
//   } catch (error) {
//     console.error("❌ Registration error:", error);
//     alert("❌ Registration failed. Please try again.");
//   }
// }

// Login Function (retrieving the locality from Firestore)
// async function loginCouncilor(email, password) {
//   try {
//     const userCredential = await signInWithEmailAndPassword(auth, email, password);
//     const user = userCredential.user;

//     const docSnap = await getDoc(doc(db, "Councillors", user.uid));

//     if (docSnap.exists()) {
//       console.log("✅ Councilor logged in:", email);
//       const locality = docSnap.data().locality;

//       // Store the locality in localStorage if it exists
//       if (locality) {
//         localStorage.setItem("councilorLocality", locality); // Store locality
//         window.location.href = "councilor_dashboard.html"; // Redirect to dashboard
//       } else {
//         alert("❌ No locality assigned. Contact support.");
//       }
//     } else {
//       alert("❌ Not a registered councilor.");
//       signOut(auth); // Log out unauthorized users
//     }
//   } catch (error) {
//     console.error("❌ Error logging in:", error);
//     alert(error.message);
//   }
// }

// Fetch Complaints (this should now use the locality from localStorage)
window.fetchComplaints = async function () {
  console.log("Inside log");

  const complaintsTableBody = document.getElementById("complaintsTableBody");
  if (!complaintsTableBody) {
    console.error("❌ Complaints table not found.");
    return;
  }

  complaintsTableBody.innerHTML = ""; // Clear existing table content
  console.log("📍 Councilor Locality from localStorage:", councilorLocality); // Debugging log

  if (!councilorLocality) {
    console.error("❌ No locality assigned. Cannot fetch complaints.");
    alert("❌ No locality assigned. Cannot fetch complaints.");
    return;
  }

  try {
    const querySnapshot = await getDocs(collection(db, "complaints"));

    querySnapshot.forEach((docSnapshot) => {
      const complaint = docSnapshot.data();

      // Only show complaints matching the councilor's locality
      if (complaint.localityName !== councilorLocality) return;

      const row = document.createElement("tr");
      row.innerHTML = `
        <td>${complaint.complaint_id}</td>  
        <td>${complaint.name}</td>
        <td>${complaint.mobileNumber}</td>
        <td>${complaint.localityName}</td>
        <td>${complaint.wardNumber}</td>
        <td>${complaint.zoneNumber}</td>
        <td>${complaint.category}</td>
        <td>${complaint.description}</td>
        <td>
          <select class="status-dropdown" data-id="${docSnapshot.id}">
            <option value="Pending" ${complaint.status === "Pending" ? "selected" : ""}>Pending</option>
            <option value="In Progress" ${complaint.status === "In Progress" ? "selected" : ""}>In Progress</option>
            <option value="Resolved" ${complaint.status === "Resolved" ? "selected" : ""}>Resolved</option>
          </select>
        </td>
      `;

      complaintsTableBody.appendChild(row);
    });

    // Attach event listeners to status dropdowns
    document.querySelectorAll(".status-dropdown").forEach((dropdown) => {
      dropdown.addEventListener("change", updateComplaintStatus);
    });

  } catch (error) {
    console.error("❌ Error fetching complaints:", error);
  }
}

onAuthStateChanged(auth, async (user) => {
  if (user) {
    const userUID = user.uid;
    currentUser = user;
    console.log("✅ Current Logged-in User UID:", userUID);

    // Fetch locality from Firestore
    const docSnap = await getDoc(doc(db, "Councillors", userUID));

    if (docSnap.exists()) {
      councilorLocality = docSnap.data().locality;
      console.log("📍 Locality stored in localStorage is equal to:", councilorLocality);
      fetchComplaints();
    } else {
      console.log("❌ Locality not found in Firestore.");
    }
  } else {
    console.log("❌ No user is signed in.");
  }
});
// Function to update complaint status
async function updateComplaintStatus(event) {
  const complaintId = event.target.getAttribute("data-id");
  const newStatus = event.target.value;

  if (!complaintId) {
    console.error("❌ Invalid Complaint ID");
    return;
  }

  try {
    await updateDoc(doc(db, "complaints", complaintId), {
      status: newStatus,
    });

    alert(`✅ Complaint status updated to ${newStatus}`);
  } catch (error) {
    console.error("❌ Error updating status:", error);
  }
}

// Function to log out councilor
window.logoutAdmin = function () {
  signOut(auth)
    .then(() => {
      alert("✅ Logout Successful!");
      localStorage.removeItem("councilorLocality"); // Clear stored locality
      window.location.href = "Councillor_login.html"; // Redirect to login page
    })
    .catch((error) => {
      console.error("❌ Logout Failed:", error);
    });
};

// Function to update UI based on authentication state
function updateAuthUI(user) {
  const loginOption = document.getElementById("login-option");
  const profileOption = document.getElementById("profile-option");
  const logoutButton = document.getElementById("logout-button");

  if (user) {
    console.log("✅ Admin Logged In:", user.email);
    if (loginOption) loginOption.style.display = "none";
    if (profileOption) profileOption.style.display = "block";
    if (logoutButton) logoutButton.style.display = "block";
  } else {
    console.log("❌ Admin Not Logged In");
    if (loginOption) loginOption.style.display = "block";
    if (profileOption) profileOption.style.display = "none";
    if (logoutButton) logoutButton.style.display = "none";
  }
}

// Check Admin Authentication and fetch complaints
// onAuthStateChanged(auth, (user) => {
//   if (user) {
//     console.log("✅ Admin Logged In:", user.email);
//     fetchComplaints(); // Ensure complaints are fetched after login
//     updateAuthUI(user);
//   } else {
//     console.log("❌ No Admin Found. Redirecting...");
//     window.location.href = "Councillor_login.html"; // Redirect to login if not logged in
//   }
// });
